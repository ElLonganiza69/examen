from defs_et import *

a=0
lista_CL = [[1],[2],[3],[4],[5],[6],[7],[8],[9],[10],
[11],[12],[13],[14],[15],[16],[17],[18],[19],[20],
[21],[22],[23],[24],[25],[26],[27],[28],[29],[30],
[31],[32],[33],[34],[35],[36],[37],[38],[39],[40],
[41],[42],[43],[44],[45],[46],[47],[48],[49],[50],
[51],[52],[53],[54],[55],[56],[57],[58],[59],[60],
[61],[62],[63],[64],[65],[66],[67],[68],[69],[70],
[71],[72],[73],[74],[75],[76],[77],[78],[79],[80],
[81],[82],[83],[84],[85],[86],[87],[88],[89],[90],
[91],[92],[93],[94],[95],[96],[97],[98],[99],[100]]

lista_AS = []

while a !=5:
    datos = []
    sil = 50000
    gld = 80000
    plt = 120000
    print("-------------------------------------")
    print("     Bienvenido a Creativos.cl      ")
    print("-------------------------------------")
    print("¿Que desea haecer?")
    print("1. Comprar entradas.")
    print("2. Mostrar ubicaciones disponibles.")
    print("3. Ver listado de asistentes.")
    print("4. Mostrar ganancias totales.")
    print("5. Salir")
    aux = int(input(" "))
    if aux == 1:
        print("¿Que categoria desea?")
        print("1. Silver")
        print("2. Gold")
        print("3. Platinum")
        st = int(input(""))
        if st == 1:
            con = silver(lista_CL)
        elif st == 2:
            con1 = gold(lista_CL)
        elif st == 3:
            con2 = plat(lista_CL)
    
    if aux == 2:
        print(lista_CL)

    if aux == 3:
        b_asis(lista_AS)

    if aux == 4:
        print("no logre esta opcion :(")
    
    if aux == 5:
        break
                

        


